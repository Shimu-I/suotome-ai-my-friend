package com.pixelgirl.pet

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    companion object {
        fun startPet(ctx: Context) {
            val i = Intent(ctx, PetService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
    }

    private fun canOverlay() = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.wave_0)
            layoutParams = LinearLayout.LayoutParams(pad * 7, pad * 10)
        })
        root.addView(TextView(this).apply {
            text = "Suotome Ai\n\nDo steps 1 to 4 once. Then she walks around while your phone is unlocked. " +
                "She stays still until you call her: double-tap (or triple-tap) a spot, or draw a circle, and she runs there to say hi. Tap her, then tap or circle anywhere. Drag her to move her. Typing never calls her."
            textSize = 16f
            gravity = Gravity.CENTER
        })
        fun btn(t: String, a: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { try { a() } catch (e: Exception) { toast("Couldn't open that screen: open it from Settings manually") } }
            root.addView(this)
        }
        btn("1. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Stop battery saver killing her") {
            if (Build.VERSION.SDK_INT >= 23)
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        btn("3. Huawei: allow auto-start / run in background") {
            try {
                startActivity(Intent().setComponent(ComponentName("com.huawei.systemmanager",
                    "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        }
        btn("4. Home screen only: turn on \"Suotome Ai (home screen only)\"") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("Start Suotome Ai") {
            if (canOverlay()) { startPet(this); toast("She's on your screen. Press Home!") }
            else toast("Do step 1 first")
        }
        btn("Stop Suotome Ai") { stopService(Intent(this, PetService::class.java)) }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
