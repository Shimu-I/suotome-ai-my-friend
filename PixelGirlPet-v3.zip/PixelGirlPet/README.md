# Pixel Girl Pet (Android)

She walks around your screen while the phone is unlocked.
- She stays still until called.
- Double/triple-tap a spot, or draw a circle: she runs there, waves, cloud says "Hi!".
- Tap her: "Where to?" for 5 seconds, then tap or circle anywhere. Drag her to move her.
- Ignores taps while the keyboard is showing.

## Build the APK (no PC tools needed except a GitHub account)
1. Create a new GitHub repo, upload ALL these files/folders (keep the .github folder).
2. Open the repo > Actions > "Build APK" > Run workflow.
3. When it finishes, open the run > Artifacts > download `pixel-girl-pet-apk`, unzip, install app-debug.apk.

Or: open this folder in Android Studio and press Run / Build APK.

## On the phone
Open the app, do buttons 1, 2, 3, 4, then Start.
Button 4: Settings > Accessibility > Installed/Downloaded services > Pixel Girl (home screen only) > turn On.
It only checks if the home screen is showing, so she hides inside other apps.
