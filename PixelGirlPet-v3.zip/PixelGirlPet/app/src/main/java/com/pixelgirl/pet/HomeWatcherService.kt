package com.pixelgirl.pet

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo

/**
 * Only job: know whether the home screen (launcher) is in front.
 * It reads no screen content and sends nothing anywhere.
 */
class HomeWatcherService : AccessibilityService() {

    companion object {
        const val ACTION = "com.pixelgirl.pet.HOME_STATE"
        @Volatile var enabled = false
        @Volatile var isHome = false
        @Volatile var imeVisible = false
    }

    private var launchers: Set<String> = emptySet()

    override fun onServiceConnected() {
        super.onServiceConnected()
        launchers = packageManager
            .queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            .map { it.activityInfo.packageName }.toSet()
        enabled = true
        isHome = false
        notifyState()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        // keyboard up? then typing must never be read as taps
        try {
            val kb = windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }
            if (kb != imeVisible) { imeVisible = kb; notifyState() }
        } catch (_: Exception) {}
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString() ?: ""
        val ime = (Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: "")
            .substringBefore('/')

        val home: Boolean = when {
            // our own overlay windows must not trigger anything; only our settings screen counts as "an app"
            pkg == packageName -> if (cls == MainActivity::class.java.name) false else return
            // status bar, notification shade, lock screen, keyboard, system popups: ignore
            pkg == "com.android.systemui" || pkg == "android" || pkg == ime -> return
            else -> pkg in launchers
        }
        if (home != isHome) {
            isHome = home
            notifyState()
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        enabled = false
        isHome = false
        notifyState()
        return super.onUnbind(intent)
    }

    private fun notifyState() {
        sendBroadcast(Intent(ACTION).setPackage(packageName))
    }
}
