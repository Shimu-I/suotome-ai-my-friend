package com.pixelgirl.pet

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import kotlin.math.hypot

class PetService : Service() {

    private enum class S { IDLE, WALK, RUN, WAVE, DRAG }

    private lateinit var wm: WindowManager
    private lateinit var pet: ImageView
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var attached = false

    private var bubble: CloudView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var bw = 0
    private var bh = 0

    private var d = 1f
    private var petW = 0
    private var petH = 0
    private var scrW = 1080
    private var scrH = 1920
    private var x = -1f
    private var y = -1f
    private var tx = 0f
    private var ty = 0f
    private var state = S.IDLE
    private var facing = 1
    private var frame = 0
    private var tickInFrame = 0
    private var timer = 60
    private var wavePending = false

    private lateinit var idleF: List<Drawable>
    private lateinit var walkF: List<Drawable>
    private lateinit var runF: List<Drawable>
    private lateinit var waveF: List<Drawable>

    private val greetings = listOf("Hi!", "Hi there!", "Hello!", "Heyyy!")

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        startForegroundCompat()
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            stopSelf(); return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        d = resources.displayMetrics.density
        petW = (84 * d).toInt()
        petH = (petW * 165f / 120f).toInt()
        fun load(vararg ids: Int) = ids.map { getDrawable(it)!! }
        idleF = load(R.drawable.idle_0, R.drawable.idle_1, R.drawable.idle_2, R.drawable.idle_3)
        walkF = load(R.drawable.walk_0, R.drawable.walk_1, R.drawable.walk_2, R.drawable.walk_3)
        runF = load(R.drawable.run_0, R.drawable.run_1, R.drawable.run_2, R.drawable.run_3)
        waveF = load(R.drawable.wave_0, R.drawable.wave_1)

        pet = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            setImageDrawable(idleF[0])
            setOnTouchListener { _, e -> onTouch(e) }
        }
        lp = WindowManager.LayoutParams(
            petW, petH, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        })
        registerReceiver(homeReceiver, IntentFilter(HomeWatcherService.ACTION))
        refresh()
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(homeReceiver) } catch (_: Exception) {}
        if (::pet.isInitialized) hidePet()
        super.onDestroy()
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> hidePet()
                Intent.ACTION_USER_PRESENT, Intent.ACTION_SCREEN_ON -> refresh()
            }
        }
    }

    // Home watcher tells us when the launcher comes to the front or an app covers it.
    private val homeReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { refresh() }
    }

    // Show only when: unlocked AND (launcher in front, or home-only mode not enabled yet).
    private fun refresh() {
        if (!::pet.isInitialized) return
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        val homeOk = !HomeWatcherService.enabled || HomeWatcherService.isHome
        if (!km.isKeyguardLocked && homeOk) showPet() else hidePet()
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("pet", "Pixel Girl", NotificationManager.IMPORTANCE_MIN))
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "pet") else Notification.Builder(this)
        val n = b.setSmallIcon(R.drawable.idle_0)
            .setContentTitle("Pixel Girl lives on your phone")
            .setContentText("Tap to open settings")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        startForeground(1, n)
    }

    // ---------- show / hide ----------
    private fun showPet() {
        if (attached) return
        val p = Point()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealSize(p)
        scrW = p.x; scrH = p.y
        if (x < 0) { x = (scrW - petW) / 2f; y = scrH * 0.55f }
        x = clampX(x); y = clampY(y)
        lp.x = x.toInt(); lp.y = y.toInt()
        try { wm.addView(pet, lp) } catch (e: Exception) { return }
        attached = true
        setState(S.IDLE)
        handler.post(tick)
    }

    private fun hidePet() {
        if (!attached) return
        handler.removeCallbacks(tick)
        removeCatcher()
        hideBubble()
        try { wm.removeView(pet) } catch (_: Exception) {}
        attached = false
    }

    // ---------- geometry ----------
    private fun clampX(v: Float) = v.coerceIn(0f, (scrW - petW).toFloat())
    private fun clampY(v: Float) = v.coerceIn(24 * d, scrH - petH - 48 * d)

    private fun apply() {
        lp.x = x.toInt(); lp.y = y.toInt()
        try { wm.updateViewLayout(pet, lp) } catch (_: Exception) {}
        val b = bubble; val bl = bubbleLp
        if (b != null && bl != null) {
            positionBubble(bl)
            try { wm.updateViewLayout(b, bl) } catch (_: Exception) {}
        }
    }

    // ---------- input ----------
    private var downX = 0f
    private var downY = 0f
    private var offX = 0f
    private var offY = 0f
    private var dragged = false

    private fun onTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_OUTSIDE -> {
                // A tap landed somewhere else. Android hides WHERE (coords are zeroed for other
                // apps/launcher), so grab the NEXT tap with a see-through catcher window.
                if (!HomeWatcherService.imeVisible) armCatcher(400)
                return true
            }
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY
                offX = e.rawX - x; offY = e.rawY - y
                dragged = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragged && hypot(e.rawX - downX, e.rawY - downY) > 8 * d) {
                    dragged = true; hideBubble(); setState(S.DRAG)
                }
                if (dragged) { x = clampX(e.rawX - offX); y = clampY(e.rawY - offY); apply() }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragged) { setState(S.IDLE) } else { wavePending = false; startWave("Where to?"); armCatcher(5000) }
                return true
            }
        }
        return false
    }

    // ---------- gesture catcher ----------
    // A full-screen see-through window that exists only for a moment:
    //  - 0.4 s after any tap (so a quick 2nd tap = double tap), or
    //  - 5 s after you tap her ("Where to?").
    // On it, a tap sends her to that spot; a circle sends her to the circle's centre.
    private var catcher: View? = null
    private var catching = false
    private val dropCatcher = Runnable { if (catching) dropAfterGesture = true else removeCatcher() }
    private var dropAfterGesture = false
    private val pts = ArrayList<FloatArray>()

    private fun armCatcher(ms: Long) {
        if (catcher != null) { handler.removeCallbacks(dropCatcher); handler.postDelayed(dropCatcher, ms); return }
        val v = View(this)
        v.setOnTouchListener { _, e -> onCatch(e); true }
        val p = WindowManager.LayoutParams(
            scrW, scrH, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        try {
            wm.addView(v, p)
            catcher = v
            handler.postDelayed(dropCatcher, ms)
        } catch (_: Exception) {}
    }

    private fun removeCatcher() {
        handler.removeCallbacks(dropCatcher)
        catching = false; dropAfterGesture = false
        catcher?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        catcher = null
    }

    private fun onCatch(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { catching = true; pts.clear(); pts.add(floatArrayOf(e.rawX, e.rawY)) }
            MotionEvent.ACTION_MOVE -> pts.add(floatArrayOf(e.rawX, e.rawY))
            MotionEvent.ACTION_UP -> {
                pts.add(floatArrayOf(e.rawX, e.rawY))
                catching = false
                val target = circleCentre() ?: tapPoint()
                handler.post { removeCatcher(); if (target != null) goTo(target[0], target[1]) }
            }
            MotionEvent.ACTION_CANCEL -> { catching = false; handler.post { removeCatcher() } }
        }
    }

    // finger barely moved = a tap
    private fun tapPoint(): FloatArray? {
        val a = pts.first(); val b = pts.last()
        return if (hypot(b[0] - a[0], b[1] - a[1]) < 24 * d && pathLength() < 40 * d) b else null
    }

    private fun pathLength(): Float {
        var l = 0f
        for (i in 1 until pts.size) l += hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])
        return l
    }

    // a loop: sweeps ~300 degrees around its own centre, ends near where it began, big enough
    private fun circleCentre(): FloatArray? {
        if (pts.size < 8) return null
        val cx = pts.map { it[0] }.average().toFloat()
        val cy = pts.map { it[1] }.average().toFloat()
        val radii = pts.map { hypot(it[0] - cx, it[1] - cy) }
        val r = radii.average().toFloat()
        if (r < 28 * d) return null
        if (radii.any { it < r * 0.45f || it > r * 1.6f }) return null
        var total = 0.0
        for (i in 1 until pts.size) {
            var da = Math.atan2((pts[i][1] - cy).toDouble(), (pts[i][0] - cx).toDouble()) -
                Math.atan2((pts[i - 1][1] - cy).toDouble(), (pts[i - 1][0] - cx).toDouble())
            while (da > Math.PI) da -= 2 * Math.PI
            while (da < -Math.PI) da += 2 * Math.PI
            total += da
        }
        if (Math.abs(total) < Math.toRadians(300.0)) return null
        val a = pts.first(); val b = pts.last()
        if (hypot(b[0] - a[0], b[1] - a[1]) > r * 0.9f) return null
        return floatArrayOf(cx, cy)
    }

    // ---------- behaviour ----------
    private fun setState(s: S) { state = s; frame = 0; tickInFrame = 0 }

    private fun goTo(ax: Float, ay: Float) {
        hideBubble()
        tx = clampX(ax - petW / 2f); ty = clampY(ay - petH / 2f)
        wavePending = true
        setState(S.RUN)
    }

    private fun startWave(text: String = greetings.random()) {
        setState(S.WAVE)
        timer = 85
        showBubble(text)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!attached) return
            step()
            handler.postDelayed(this, 33)
        }
    }

    private fun step() {
        var moved = false
        when (state) {
            S.WALK, S.RUN -> {
                val dx = tx - x; val dy = ty - y
                val dist = hypot(dx, dy)
                val sp = (if (state == S.RUN) 6f else 2f) * d
                if (dist <= sp) {
                    x = tx; y = ty; moved = true
                    if (wavePending) { wavePending = false; startWave() }
                    else { setState(S.IDLE) }
                } else {
                    x += dx / dist * sp; y += dy / dist * sp; moved = true
                    if (dx < -1) facing = -1 else if (dx > 1) facing = 1
                }
            }
            S.IDLE -> {}  // she only moves when you call her
            S.WAVE -> if (--timer <= 0) { hideBubble(); setState(S.IDLE) }
            S.DRAG -> {}
        }
        val frames = when (state) { S.WALK -> walkF; S.RUN -> runF; S.WAVE -> waveF; else -> idleF }
        val every = when (state) { S.WALK -> 4; S.RUN -> 3; S.WAVE -> 6; else -> 12 }
        if (++tickInFrame >= every) { tickInFrame = 0; frame++ }
        pet.setImageDrawable(frames[frame % frames.size])
        pet.scaleX = if (state == S.WAVE) 1f else -facing.toFloat()  // art faces left
        if (moved) apply()
    }

    // ---------- speech bubble ----------
    private fun positionBubble(p: WindowManager.LayoutParams) {
        p.x = (x + petW / 2f - bw / 2f).toInt().coerceIn(0, (scrW - bw).coerceAtLeast(0))
        p.y = (y - bh + 14 * d).toInt().coerceAtLeast(0)
    }

    private fun showBubble(text: String) {
        hideBubble()
        bw = (120 * d).toInt(); bh = (70 * d).toInt()
        val b = CloudView(this, text)
        val p = WindowManager.LayoutParams(
            bw, bh, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        positionBubble(p)
        try { wm.addView(b, p); bubble = b; bubbleLp = p } catch (_: Exception) {}
    }

    private fun hideBubble() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null; bubbleLp = null
    }
}
