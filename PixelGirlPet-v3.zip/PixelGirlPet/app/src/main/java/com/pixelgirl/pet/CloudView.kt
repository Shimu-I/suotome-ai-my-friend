package com.pixelgirl.pet

import android.content.Context
import android.graphics.*
import android.view.View

/** A little cloud-shaped speech bubble with text inside. */
class CloudView(ctx: Context, private val msg: String) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val dark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(58, 26, 16) }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(58, 26, 16)
        textSize = 17 * d
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }

    private fun shapes(c: Canvas, p: Paint, g: Float) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRoundRect(RectF(0.10f * w - g, 0.30f * h - g, 0.90f * w + g, 0.78f * h + g),
            0.24f * h + g, 0.24f * h + g, p)
        c.drawCircle(0.30f * w, 0.36f * h, 0.20f * h + g, p)
        c.drawCircle(0.55f * w, 0.30f * h, 0.25f * h + g, p)
        c.drawCircle(0.76f * w, 0.40f * h, 0.17f * h + g, p)
        c.drawCircle(0.50f * w, 0.88f * h, 0.07f * h + g, p)
        c.drawCircle(0.45f * w, 0.97f * h, 0.04f * h + g, p)
    }

    override fun onDraw(c: Canvas) {
        shapes(c, dark, 2.5f * d)
        shapes(c, white, 0f)
        c.drawText(msg, width / 2f, 0.52f * height + text.textSize / 3f, text)
    }
}
