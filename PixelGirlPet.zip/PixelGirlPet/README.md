# Pixel Girl Pet (Android)

She walks around your screen while the phone is unlocked.
- Double-tap an empty spot: she runs there, waves, and a cloud says "Hi!".
- Tap her: she waves. Drag her: she moves.

## Build the APK (no PC tools needed except a GitHub account)
1. Create a new GitHub repo, upload ALL these files/folders (keep the .github folder).
2. Open the repo > Actions > "Build APK" > Run workflow.
3. When it finishes, open the run > Artifacts > download `pixel-girl-pet-apk`, unzip, install app-debug.apk.

Or: open this folder in Android Studio and press Run / Build APK.

## On the phone
Open the app, do buttons 1, 2, 3, then Start.
