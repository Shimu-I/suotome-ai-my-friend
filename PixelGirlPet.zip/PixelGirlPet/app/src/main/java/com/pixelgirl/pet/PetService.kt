package com.pixelgirl.pet

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.ImageView
import kotlin.math.hypot
import kotlin.random.Random

class PetService : Service() {

    private enum class S { IDLE, WALK, RUN, WAVE, DRAG }

    private lateinit var wm: WindowManager
    private lateinit var pet: ImageView
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var attached = false

    private var bubble: CloudView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var bw = 0
    private var bh = 0

    private var d = 1f
    private var petW = 0
    private var petH = 0
    private var scrW = 1080
    private var scrH = 1920
    private var x = -1f
    private var y = -1f
    private var tx = 0f
    private var ty = 0f
    private var state = S.IDLE
    private var facing = 1
    private var frame = 0
    private var tickInFrame = 0
    private var timer = 60
    private var wavePending = false

    private lateinit var idleF: List<Drawable>
    private lateinit var walkF: List<Drawable>
    private lateinit var runF: List<Drawable>
    private lateinit var waveF: List<Drawable>

    private val greetings = listOf("Hi!", "Hi there!", "Hello!", "Heyyy!")

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        startForegroundCompat()
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            stopSelf(); return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        d = resources.displayMetrics.density
        petW = (84 * d).toInt()
        petH = (petW * 165f / 120f).toInt()
        fun load(vararg ids: Int) = ids.map { getDrawable(it)!! }
        idleF = load(R.drawable.idle_0, R.drawable.idle_1, R.drawable.idle_2, R.drawable.idle_3)
        walkF = load(R.drawable.walk_0, R.drawable.walk_1, R.drawable.walk_2, R.drawable.walk_3)
        runF = load(R.drawable.run_0, R.drawable.run_1, R.drawable.run_2, R.drawable.run_3)
        waveF = load(R.drawable.wave_0, R.drawable.wave_1)

        pet = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            setImageDrawable(idleF[0])
            setOnTouchListener { _, e -> onTouch(e) }
        }
        lp = WindowManager.LayoutParams(
            petW, petH, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        })
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) showPet()
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        if (::pet.isInitialized) hidePet()
        super.onDestroy()
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> hidePet()
                Intent.ACTION_USER_PRESENT -> showPet()
                Intent.ACTION_SCREEN_ON -> {
                    val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
                    if (!km.isKeyguardLocked) showPet()
                }
            }
        }
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("pet", "Pixel Girl", NotificationManager.IMPORTANCE_MIN))
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "pet") else Notification.Builder(this)
        val n = b.setSmallIcon(R.drawable.idle_0)
            .setContentTitle("Pixel Girl lives on your phone")
            .setContentText("Tap to open settings")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        startForeground(1, n)
    }

    // ---------- show / hide ----------
    private fun showPet() {
        if (attached) return
        val p = Point()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealSize(p)
        scrW = p.x; scrH = p.y
        if (x < 0) { x = (scrW - petW) / 2f; y = scrH * 0.55f }
        x = clampX(x); y = clampY(y)
        lp.x = x.toInt(); lp.y = y.toInt()
        try { wm.addView(pet, lp) } catch (e: Exception) { return }
        attached = true
        setState(S.IDLE); timer = 30
        handler.post(tick)
    }

    private fun hidePet() {
        if (!attached) return
        handler.removeCallbacks(tick)
        hideBubble()
        try { wm.removeView(pet) } catch (_: Exception) {}
        attached = false
    }

    // ---------- geometry ----------
    private fun clampX(v: Float) = v.coerceIn(0f, (scrW - petW).toFloat())
    private fun clampY(v: Float) = v.coerceIn(24 * d, scrH - petH - 48 * d)

    private fun apply() {
        lp.x = x.toInt(); lp.y = y.toInt()
        try { wm.updateViewLayout(pet, lp) } catch (_: Exception) {}
        val b = bubble; val bl = bubbleLp
        if (b != null && bl != null) {
            positionBubble(bl)
            try { wm.updateViewLayout(b, bl) } catch (_: Exception) {}
        }
    }

    // ---------- input ----------
    private var downX = 0f
    private var downY = 0f
    private var offX = 0f
    private var offY = 0f
    private var dragged = false
    private var lastOutT = 0L
    private var lastOutX = 0f
    private var lastOutY = 0f

    private fun onTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_OUTSIDE -> {
                // A touch landed somewhere else on screen (e.g. the home screen).
                val ax = lp.x + e.x
                val ay = lp.y + e.y
                val now = SystemClock.uptimeMillis()
                if (now - lastOutT < 350 && hypot(ax - lastOutX, ay - lastOutY) < 70 * d) {
                    lastOutT = 0
                    goTo(ax, ay)
                } else {
                    lastOutT = now; lastOutX = ax; lastOutY = ay
                }
                return true
            }
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY
                offX = e.rawX - x; offY = e.rawY - y
                dragged = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragged && hypot(e.rawX - downX, e.rawY - downY) > 8 * d) {
                    dragged = true; hideBubble(); setState(S.DRAG)
                }
                if (dragged) { x = clampX(e.rawX - offX); y = clampY(e.rawY - offY); apply() }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragged) { setState(S.IDLE); timer = 40 } else { wavePending = false; startWave() }
                return true
            }
        }
        return false
    }

    // ---------- behaviour ----------
    private fun setState(s: S) { state = s; frame = 0; tickInFrame = 0 }

    private fun goTo(ax: Float, ay: Float) {
        hideBubble()
        tx = clampX(ax - petW / 2f); ty = clampY(ay - petH / 2f)
        wavePending = true
        setState(S.RUN)
    }

    private fun startWave() {
        setState(S.WAVE)
        timer = 85
        showBubble(greetings.random())
    }

    private fun wander() {
        tx = clampX(x + Random.nextInt(-200, 201) * d)
        ty = clampY(y + Random.nextInt(-150, 151) * d)
        wavePending = false
        setState(S.WALK)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!attached) return
            step()
            handler.postDelayed(this, 33)
        }
    }

    private fun step() {
        var moved = false
        when (state) {
            S.WALK, S.RUN -> {
                val dx = tx - x; val dy = ty - y
                val dist = hypot(dx, dy)
                val sp = (if (state == S.RUN) 6f else 2f) * d
                if (dist <= sp) {
                    x = tx; y = ty; moved = true
                    if (wavePending) { wavePending = false; startWave() }
                    else { setState(S.IDLE); timer = Random.nextInt(60, 200) }
                } else {
                    x += dx / dist * sp; y += dy / dist * sp; moved = true
                    if (dx < -1) facing = -1 else if (dx > 1) facing = 1
                }
            }
            S.IDLE -> if (--timer <= 0) wander()
            S.WAVE -> if (--timer <= 0) { hideBubble(); setState(S.IDLE); timer = Random.nextInt(60, 150) }
            S.DRAG -> {}
        }
        val frames = when (state) { S.WALK -> walkF; S.RUN -> runF; S.WAVE -> waveF; else -> idleF }
        val every = when (state) { S.WALK -> 4; S.RUN -> 3; S.WAVE -> 6; else -> 12 }
        if (++tickInFrame >= every) { tickInFrame = 0; frame++ }
        pet.setImageDrawable(frames[frame % frames.size])
        pet.scaleX = if (state == S.WAVE) 1f else facing.toFloat()
        if (moved) apply()
    }

    // ---------- speech bubble ----------
    private fun positionBubble(p: WindowManager.LayoutParams) {
        p.x = (x + petW / 2f - bw / 2f).toInt().coerceIn(0, (scrW - bw).coerceAtLeast(0))
        p.y = (y - bh + 14 * d).toInt().coerceAtLeast(0)
    }

    private fun showBubble(text: String) {
        hideBubble()
        bw = (120 * d).toInt(); bh = (70 * d).toInt()
        val b = CloudView(this, text)
        val p = WindowManager.LayoutParams(
            bw, bh, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        positionBubble(p)
        try { wm.addView(b, p); bubble = b; bubbleLp = p } catch (_: Exception) {}
    }

    private fun hideBubble() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null; bubbleLp = null
    }
}
